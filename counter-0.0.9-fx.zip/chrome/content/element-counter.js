/*
 *  Counter 0.0.6
 *  Shitesh Sachan
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation.
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

//
// Taken help from  Web developer Andrew Ziem, Chris Pederick
// http://chrispederick.com/work/web-developer/help/
//XML User Interface Language(XUL)



// Purpose: The main function to do hard work
//
// Parameters

if ("undefined" == typeof(header_counter)) {
  var header_counter = {};
};


//   searchstring: blank ("") means no filtering, otherwise look for this string
 header_counter.Count_extractLinksMain=function(searchstring) {

	// extract the links
	
	var webdeveloper_getDocumentBodyElement= function (contentDocument)
{
    // If there is a body element
    if(contentDocument.body)
    {
        return contentDocument.body;
    }
    else
    {
        var bodyElementList = contentDocument.getElementsByTagName("body");

        // If there is a body element
        if(bodyElementList.length > 0)
        {
            return bodyElementList[0];
        }
    }

    return contentDocument.documentElement;
}

// Generates a document in a new tab or window

var webdeveloper_generateDocument= function(url)
{
    var generatedPage = null;
    var request       = new XMLHttpRequest();

    getBrowser().selectedTab = getBrowser().addTab(url);
    generatedPage = window;
    var openedWindow;
	openedWindow=window.open(url, '_blank');
	openedWindow.close();
	//focus();
	
    // This must be done to make generated content render Synchronously
    //request.open("get", "about:blank", false);
   // request.send(null);
	//if (request.status === 200) {  
    //console.log(request.responseText);  
   //}  
   
    // This must be done to make generated content render Asynchronously








    return generatedPage.content.document;
}


 var Count_remove_duplicate_elements=function(a)
{
	var a = a.sort();
	var a2 = new Array();
	a2.push(a[0]);
	for (var i = 1; i < a.length; i++)
	{	
		if (a[i] != a[i-1])
		{
			a2.push(a[i]);
		}
	}
	return a2;
}

// purpose: generate list of links in a given HTML document
//
// parameters
//  doc = document
//  links = array of links

var Count_available_links=function(doc, bodyElement, links)
{
	var headerElement = doc.createElement("h2");
	headerElement.appendChild(doc.createTextNode("URLS"));
	bodyElement.appendChild(headerElement);

    header_counter.foundLinks = 0;
	for (var i = 0; i < links.length; i++)
	{	
		var linkElement   = doc.createElement("a");
		linkElement.setAttribute("href", links[i]);
		linkElement.appendChild(doc.createTextNode(links[i]));

		bodyElement.appendChild(doc.createElement("br"));
		bodyElement.appendChild(linkElement);
		header_counter.foundLinks++;
	}
	var headerElement = doc.createElement("h2");
	headerElement.appendChild(doc.createTextNode("No of found urls--> "+header_counter.foundLinks));
	bodyElement.appendChild(headerElement);

}
	//var inputs = content.document.getElementsByTagName("input");
    var textcount = 0;
    for(var cpt = 1; cpt < content.document.getElementsByTagName("input").length; cpt++)
    if (( content.document.getElementsByTagName("input")[cpt].type == "text" ) || ( content.document.getElementsByTagName("input")[cpt].type == "password" )  || ( content.document.getElementsByTagName("input")[cpt].type == "email" ))
    {
    textcount++;
    }

//var buttons = content.document.getElementsByTagName("button").length;


// counting number of available buttons with tag name input and button
    //var buttons = content.document.getElementsByTagName("input");
    var bcount = 0; 
    for(var bcpt = 1; bcpt < content.document.getElementsByTagName("input").length; bcpt++)
    if (( content.document.getElementsByTagName("input")[bcpt].type == "button" ) || ( content.document.getElementsByTagName("input")[bcpt].type == "submit" ))
     {
     bcount++;
     }

    //var newbuttons = content.document.getElementsByTagName("button");
    var newbcount = 0;
    for(var newbcpt = 1; newbcpt < content.document.getElementsByTagName("button").length; newbcpt++)
      if (( content.document.getElementsByTagName("button")[newbcpt].type == "button" ) || ( content.document.getElementsByTagName("button")[newbcpt].type == "submit" ))
       {
        newbcount++;
       }
var adder=bcount+newbcount

var links = new Array();
	
	for (var i = 0; i < content.document.links.length; i++)
	{	
		var thisLink = content.document.links[i].toString();
		if("" == searchstring || thisLink.indexOf(searchstring) > -1)
			links.push(content.document.links[i].toString());
	}

	// open tab
	var doc =  webdeveloper_generateDocument("");
	doc.title = "All URLS";
	var bodyElement = webdeveloper_getDocumentBodyElement(doc);

	// find embedded links
	var embedded_links = new Array();
	for (var i = 0; i < links.length; i++)
	{	
		var link = links[i];
		link = link.replace(/%3[Aa]/g,":");
		link = link.replace(/%2[fF]/g, "\/");
		var re  =  /.(https?:\/\/.*)/g;
		var a = link.match(re);
		if (a !== null && a.length > 0)
		{
			embedded_links.push(a[0].substring(1));
		}
	}
	var links = links.concat(embedded_links);

	//  remove duplicates
	var links = Count_remove_duplicate_elements(links);

	// display links
	Count_available_links(doc, bodyElement, links);

	// find domains
	var domains = new Array();
	for (var i = 0; i < links.length; i++)
	{	
		var link = links[i];
		var re  =  /https?:\/\/([^\/]*)\/?/g;
		var a = link.match(re);
		if (a !== null && a.length > 0)
		{
			domains = domains.concat(a);
		}
	}

	// remove duplicates
	var domains = Count_remove_duplicate_elements(domains);

	// display domains
	var headerElement = doc.createElement("h2");
	headerElement.appendChild(doc.createTextNode("Domains urls"));
	bodyElement.appendChild(headerElement);
    var foundDomains = 0;
	for (var i = 0; i < domains.length; i++)
	{	
		var linkElement = doc.createElement("a");
		linkElement.setAttribute("href", domains[i]);
		linkElement.appendChild(doc.createTextNode(domains[i]));


		bodyElement.appendChild(doc.createElement("br"));
		bodyElement.appendChild(linkElement);
		foundDomains++;
	}
   var headerElement = doc.createElement("h2");
	headerElement.appendChild(doc.createTextNode("No of found Domain urls--> "+foundDomains));
	bodyElement.appendChild(headerElement);
	alert("Found links -->  " + header_counter.foundLinks + "\nFound Domains -->  " + foundDomains + "\nFound Textfields --> "+textcount +"\nFound Buttons --> "+adder);
	
}


// The common function called from XUL.
header_counter.Count_ExtractAllLinks=function() {
	header_counter.Count_extractLinksMain("");
	

}



//adding "count_"with all funcitons in V 0.0.2
// Called from XUL to show usage instructions and support info.

